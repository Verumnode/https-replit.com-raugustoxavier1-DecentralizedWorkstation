# 🛒 COMO COMPRAR DOMÍNIO NO REPLIT

## 📍 LOCALIZAÇÃO NO REPLIT

### Passo 1: Acesse as Configurações
1. **Vá para seu Repl do VERUM OS**
2. **Clique na aba "Settings" (Configurações)**
3. **Procure por "Domains" ou "Custom Domain"**
4. **Clique em "Add Domain" ou "Purchase Domain"**

### Passo 2: Pesquise Disponibilidade
1. **Digite: `verumos.com`**
2. **Clique em "Check Availability"**
3. **Se disponível, verá preço (geralmente $12-20/ano)**
4. **Se não disponível, teste alternativas:**
   - `verumnode.com`
   - `verumos.app` 
   - `verumai.com`
   - `verumos.io`

### Passo 3: Configuração Automática
1. **Clique "Purchase" no domínio escolhido**
2. **Preencha dados de pagamento**
3. **Confirme compra**
4. **Replit configura SSL e DNS automaticamente**

## 🔍 SE NÃO ENCONTRAR A OPÇÃO

### Alternativa 1: Menu Principal
- **Dashboard Replit** → **Account Settings** → **Domains**

### Alternativa 2: Repl Específico
- **Seu Repl** → **Settings** → **Hosting** → **Custom Domain**

### Alternativa 3: Contato Suporte
- Se não encontrar, pode ser feature em rollout
- **Contate suporte Replit**: support@replit.com
- **Mencione**: "Quero comprar domínio customizado para meu Repl"

## 💳 INFORMAÇÕES DE PAGAMENTO

### Preços Típicos
- **.com**: $12-15/ano
- **.app**: $15-20/ano  
- **.io**: $25-35/ano
- **.ai**: $50-80/ano

### Métodos Aceitos
- Cartão de crédito
- PayPal
- Alguns métodos locais

### Renovação
- Automática por padrão
- Pode cancelar auto-renewal
- Notificações antes do vencimento

## ⚡ CONFIGURAÇÃO IMEDIATA

### O que o Replit faz automaticamente:
1. **DNS Configuration** - Aponta para seu Repl
2. **SSL Certificate** - HTTPS habilitado
3. **CDN Setup** - Performance global
4. **Redirects** - www → domain principal

### Tempo de Propagação:
- **DNS**: 5-15 minutos
- **SSL**: 10-30 minutos  
- **Totalmente funcional**: < 1 hora

## 🎯 APÓS A COMPRA

### Teste Imediato:
```bash
# Teste DNS
nslookup verumos.com

# Teste SSL
curl -I https://verumos.com
```

### Configurações Adicionais:
- **Email forwarding**: rafael@verumos.com → seu email atual
- **Subdomains**: api.verumos.com, docs.verumos.com
- **Analytics**: Google Analytics com domínio próprio

## 🚀 RESULTADO FINAL

### Antes:
`https://complex-repl-name-123.username.repl.co`

### Depois:
`https://verumos.com`

### Email Profissional:
`rafael@verumos.com`

**PRONTO PARA BRASÍLIA COM CREDIBILIDADE ENTERPRISE!** 🎯

---

**💡 DICA EXTRA:** Compre hoje mesmo! Domínios .com populares podem ser registrados por outros rapidamente.