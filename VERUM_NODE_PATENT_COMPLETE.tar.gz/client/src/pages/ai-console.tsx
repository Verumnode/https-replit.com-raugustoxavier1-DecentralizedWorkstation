import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, Shield, Zap, Database, Activity, Cpu, HardDrive, Network } from 'lucide-react';

interface AIAnalysis {
  systemHealth: string;
  optimizations: string[];
  recommendations: string[];
  consolidationPlan: string;
}

interface AIInsights {
  insights: string;
  timestamp: string;
}

interface SecurityAssessment {
  assessment: string;
  timestamp: string;
}

export default function AIConsole() {
  const [consolidationProgress, setConsolidationProgress] = useState(94);
  const [systemStats, setSystemStats] = useState({
    cpu: 12,
    memory: 7.5,
    disk: 45,
    network: 98
  });
  const queryClient = useQueryClient();

  const { data: analysis, isLoading: analysisLoading } = useQuery<AIAnalysis>({
    queryKey: ['/api/ai/system-analysis'],
    refetchInterval: 30000,
  });

  const { data: insights, isLoading: insightsLoading } = useQuery<AIInsights>({
    queryKey: ['/api/ai/insights'],
    refetchInterval: 60000,
  });

  const { data: security, isLoading: securityLoading } = useQuery<SecurityAssessment>({
    queryKey: ['/api/ai/security-assessment'],
    refetchInterval: 45000,
  });

  const consolidationMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/ai/system-analysis', { method: 'GET' });
      if (!response.ok) throw new Error('Failed to run consolidation');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai/system-analysis'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ai/insights'] });
      setConsolidationProgress(Math.min(100, consolidationProgress + 3));
    },
  });

  const analysisMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/ai/insights', { method: 'GET' });
      if (!response.ok) throw new Error('Failed to generate insights');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai/insights'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ai/system-analysis'] });
    },
  });

  const securityMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/ai/security-assessment', { method: 'GET' });
      if (!response.ok) throw new Error('Failed to run security assessment');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai/security-assessment'] });
    },
  });

  // Simular atualizações em tempo real dos stats do sistema
  useEffect(() => {
    const interval = setInterval(() => {
      setSystemStats(prev => ({
        cpu: Math.max(5, Math.min(25, prev.cpu + (Math.random() - 0.5) * 4)),
        memory: Math.max(6, Math.min(12, prev.memory + (Math.random() - 0.5) * 0.5)),
        disk: Math.max(40, Math.min(60, prev.disk + (Math.random() - 0.5) * 2)),
        network: Math.max(85, Math.min(100, prev.network + (Math.random() - 0.5) * 5))
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Brain className="h-8 w-8 text-emerald-400" />
            <div>
              <h1 className="text-3xl font-bold">VERUM AI Console</h1>
              <p className="text-gray-400">Enterprise v2.4.1 • Claude Sonnet-4 & GPT-4o</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
              <Activity className="h-3 w-3 mr-1" />
              Online
            </Badge>
            <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
              GPT-4o Enabled
            </Badge>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex space-x-3">
          <Button
            onClick={() => analysisMutation.mutate()}
            disabled={analysisMutation.isPending}
            className="bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            <Brain className="h-4 w-4 mr-2" />
            {analysisMutation.isPending ? 'Analyzing...' : 'Run AI Analysis'}
          </Button>
          
          <Button
            onClick={() => consolidationMutation.mutate()}
            disabled={consolidationMutation.isPending}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Database className="h-4 w-4 mr-2" />
            {consolidationMutation.isPending ? 'Consolidating...' : 'Consolidate Base'}
          </Button>
          
          <Button
            onClick={() => securityMutation.mutate()}
            disabled={securityMutation.isPending}
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            <Shield className="h-4 w-4 mr-2" />
            {securityMutation.isPending ? 'Scanning...' : 'Security Scan'}
          </Button>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-gray-800/50 border border-gray-700">
            <TabsTrigger value="overview" className="data-[state=active]:bg-gray-700">
              <Brain className="h-4 w-4 mr-2" />
              AI Overview
            </TabsTrigger>
            <TabsTrigger value="analysis" className="data-[state=active]:bg-gray-700">
              <Activity className="h-4 w-4 mr-2" />
              System Analysis
            </TabsTrigger>
            <TabsTrigger value="insights" className="data-[state=active]:bg-gray-700">
              <Zap className="h-4 w-4 mr-2" />
              Strategic Insights
            </TabsTrigger>
            <TabsTrigger value="security" className="data-[state=active]:bg-gray-700">
              <Shield className="h-4 w-4 mr-2" />
              Security Assessment
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* System Status */}
              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center text-emerald-400">
                    <Activity className="h-5 w-5 mr-2" />
                    System Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="flex items-center"><Cpu className="h-4 w-4 mr-1" />CPU</span>
                      <span>{systemStats.cpu.toFixed(1)}%</span>
                    </div>
                    <Progress value={systemStats.cpu} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="flex items-center"><HardDrive className="h-4 w-4 mr-1" />Memory</span>
                      <span>{systemStats.memory.toFixed(1)} GB</span>
                    </div>
                    <Progress value={(systemStats.memory / 16) * 100} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="flex items-center"><Network className="h-4 w-4 mr-1" />Network</span>
                      <span>{systemStats.network.toFixed(0)}%</span>
                    </div>
                    <Progress value={systemStats.network} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              {/* AI Models Status */}
              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center text-blue-400">
                    <Brain className="h-5 w-5 mr-2" />
                    AI Models
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Claude Sonnet-4</span>
                    <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                      Active
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span>GPT-4o</span>
                    <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                      Connected
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span>AXON OMEGA</span>
                    <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                      Online
                    </Badge>
                  </div>
                  
                  <div className="text-sm text-gray-400 mt-4">
                    Response Time: 1.2s avg<br />
                    Analysis Accuracy: 98.7%
                  </div>
                </CardContent>
              </Card>

              {/* Consolidation Progress */}
              <Card className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center text-purple-400">
                    <Database className="h-5 w-5 mr-2" />
                    Base Consolidation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-400 mb-2">
                      {consolidationProgress}%
                    </div>
                    <Progress value={consolidationProgress} className="h-3 mb-4" />
                    <p className="text-sm text-gray-400">
                      Overall System Health
                    </p>
                  </div>
                  
                  <div className="text-xs text-gray-500 space-y-1">
                    <div>• Database optimization: Complete</div>
                    <div>• Security protocols: Active</div>
                    <div>• Module integration: 94%</div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle>Recent AI Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between items-center py-2 border-b border-gray-700/50">
                    <span>System Health Check</span>
                    <span className="text-gray-400">2 min ago</span>
                  </div>
                  <div className="text-xs text-gray-500 ml-4">
                    AI performed comprehensive system analysis
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-gray-700/50">
                    <span>Security Assessment</span>
                    <span className="text-gray-400">5 min ago</span>
                  </div>
                  <div className="text-xs text-gray-500 ml-4">
                    AXON OMEGA protocol validation completed
                  </div>
                  
                  <div className="flex justify-between items-center py-2">
                    <span>Application Optimization</span>
                    <span className="text-gray-400">12 min ago</span>
                  </div>
                  <div className="text-xs text-gray-500 ml-4">
                    Metadata enhancement for enterprise applications
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2 text-emerald-400" />
                  System Analysis Results
                </CardTitle>
              </CardHeader>
              <CardContent>
                {analysisLoading || analysisMutation.isPending ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-400"></div>
                    <span className="ml-3">Analyzing system...</span>
                  </div>
                ) : analysis ? (
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-semibold text-emerald-400 mb-2">System Health</h4>
                      <p className="text-gray-300">{analysis.systemHealth}</p>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-blue-400 mb-2">Optimizations</h4>
                      <ul className="space-y-1 text-gray-300">
                        {analysis.optimizations.map((opt, index) => (
                          <li key={index} className="flex items-start">
                            <Zap className="h-4 w-4 mr-2 mt-0.5 text-yellow-400" />
                            {opt}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-purple-400 mb-2">Recommendations</h4>
                      <ul className="space-y-1 text-gray-300">
                        {analysis.recommendations.map((rec, index) => (
                          <li key={index} className="flex items-start">
                            <Brain className="h-4 w-4 mr-2 mt-0.5 text-purple-400" />
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    Click "Run AI Analysis" to generate comprehensive system insights
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="h-5 w-5 mr-2 text-yellow-400" />
                  Strategic AI Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                {insightsLoading || analysisMutation.isPending ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-400"></div>
                    <span className="ml-3">Generating insights...</span>
                  </div>
                ) : insights ? (
                  <div className="space-y-4">
                    <p className="text-gray-300 leading-relaxed">{insights.insights}</p>
                    <div className="text-sm text-gray-500">
                      Generated: {new Date(insights.timestamp).toLocaleString()}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    Strategic insights will appear here after running analysis
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-red-400" />
                  Security Assessment
                </CardTitle>
              </CardHeader>
              <CardContent>
                {securityLoading || securityMutation.isPending ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-400"></div>
                    <span className="ml-3">Running security scan...</span>
                  </div>
                ) : security ? (
                  <div className="space-y-4">
                    <p className="text-gray-300 leading-relaxed">{security.assessment}</p>
                    <div className="text-sm text-gray-500">
                      Last scan: {new Date(security.timestamp).toLocaleString()}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    Click "Security Scan" to run comprehensive security assessment
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}