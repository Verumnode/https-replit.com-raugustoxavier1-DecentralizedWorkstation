import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function VerumAIChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [activeAI, setActiveAI] = useState<'llama' | 'claude' | 'mistral' | 'gemini'>('claude');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const endpoint = activeAI === 'claude' ? '/api/claude/chat' : 
                     activeAI === 'llama' ? '/api/llama/chat' : 
                     activeAI === 'mistral' ? '/api/mistral/chat' : '/api/gemini/chat';
      
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
      
      if (!response.ok) {
        throw new Error(`Falha na comunicação com ${activeAI.toUpperCase()} AI`);
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: data.response,
        timestamp: new Date()
      }]);
    },
    onError: (error: any) => {
      const errorMessage = error?.message?.includes('Too Many Requests') 
        ? `Limite de uso da API ${activeAI.toUpperCase()} atingido. Tente novamente mais tarde.`
        : `Falha ao comunicar com ${activeAI.toUpperCase()} AI. Verifique a configuração do sistema.`;
      
      toast({
        title: `Erro ${activeAI.toUpperCase()} AI`,
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const handleSend = () => {
    if (!input.trim()) return;
    
    const userMessage: ChatMessage = {
      role: 'user',
      content: input,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    chatMutation.mutate(input);
    setInput('');
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-white p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-light mb-2">VERUM AI Console</h1>
          <p className="text-gray-400">Sistema de IA 100% VERUM NODE - Zero Third Party</p>
          <p className="text-xs text-red-400 mt-2">⚠️ URL /openai-chat foi redirecionada para VERUM AI nativo</p>
          
          {/* AI Provider Selector */}
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => setActiveAI('claude')}
              className={`px-4 py-2 rounded-lg transition-all ${
                activeAI === 'claude' 
                  ? 'bg-[#00d4aa] text-black font-semibold' 
                  : 'bg-[#2a2a2a] text-gray-400 hover:bg-[#3a3a3a]'
              }`}
            >
              VERUM AI v1
            </button>
            <button
              onClick={() => setActiveAI('llama')}
              className={`px-4 py-2 rounded-lg transition-all ${
                activeAI === 'llama' 
                  ? 'bg-blue-500 text-white font-semibold' 
                  : 'bg-[#2a2a2a] text-gray-400 hover:bg-[#3a3a3a]'
              }`}
            >
              VERUM AI v2
            </button>
            <button
              onClick={() => setActiveAI('mistral')}
              className={`px-4 py-2 rounded-lg transition-all ${
                activeAI === 'mistral' 
                  ? 'bg-purple-500 text-white font-semibold' 
                  : 'bg-[#2a2a2a] text-gray-400 hover:bg-[#3a3a3a]'
              }`}
            >
              VERUM AI v3
            </button>
            <button
              onClick={() => setActiveAI('gemini')}
              className={`px-4 py-2 rounded-lg transition-all ${
                activeAI === 'gemini' 
                  ? 'bg-yellow-500 text-black font-semibold' 
                  : 'bg-[#2a2a2a] text-gray-400 hover:bg-[#3a3a3a]'
              }`}
            >
              VERUM AI v4 💎
            </button>
          </div>
        </div>

        <Card className="bg-[#1a1a1a] border-[#2a2a2a] mb-6 h-96 overflow-y-auto p-4">
          {messages.length === 0 ? (
            <div className="text-center text-gray-500 mt-20">
              <p>Inicie uma conversa com a IA</p>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-lg ${
                    message.role === 'user' 
                      ? 'bg-[#00d4aa] text-black' 
                      : 'bg-[#2a2a2a] text-white'
                  }`}>
                    <p className="whitespace-pre-wrap">{message.content}</p>
                    <span className="text-xs opacity-70 mt-1 block">
                      {message.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))}
              {chatMutation.isPending && (
                <div className="flex justify-start">
                  <div className="bg-[#2a2a2a] p-3 rounded-lg">
                    <p className="text-gray-400">{activeAI.toUpperCase()} está processando...</p>
                  </div>
                </div>
              )}
            </div>
          )}
        </Card>

        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Digite sua mensagem..."
            className="bg-[#1a1a1a] border-[#2a2a2a] text-white flex-1"
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          />
          <Button 
            onClick={handleSend}
            disabled={chatMutation.isPending || !input.trim()}
            className="bg-[#00d4aa] hover:bg-[#00b894] text-black"
          >
            Enviar
          </Button>
        </div>
      </div>
    </div>
  );
}